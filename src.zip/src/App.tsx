import { useState, useRef } from 'react';
import GameClock from './components/GameClock';
import PlayerPanel, { StatType, PlayerStatus } from './components/PlayerPanel';
import EventBlockGenerator, { EventData } from './components/EventBlockGenerator';
import './App.css';

function App() {
  const [currentQuarter, setCurrentQuarter] = useState<number>(1);
  const [timelineEvents, setTimelineEvents] = useState<EventData[]>([]);
  const [nextTimelinePoint, setNextTimelinePoint] = useState<number>(1);
  
  // Refs to access component methods
  const gameClockRef = useRef<any>(null);
  const playerPanelRef = useRef<{
    logAction: (statType: StatType) => void;
    setPlayerStatus: (status: PlayerStatus) => void;
  } | null>(null);

  // Callback to track quarter changes from GameClock
  const handleQuarterChange = (quarter: number) => {
    setCurrentQuarter(quarter);
  };
  
  // Function to log player actions
  const logPlayerAction = (statType: StatType) => {
    if (playerPanelRef.current) {
      playerPanelRef.current.logAction(statType);
    }
  };
  
  // Function to set player status
  const setPlayerStatus = (status: PlayerStatus) => {
    if (playerPanelRef.current) {
      playerPanelRef.current.setPlayerStatus(status);
    }
  };
  
  // Function to advance game time
  const advanceGameTime = (seconds: number) => {
    if (gameClockRef.current) {
      gameClockRef.current.advanceTime(seconds);
    }
  };
  
  // Handle event block generation completion
  const handleEventGenerated = (eventData: EventData) => {
    setTimelineEvents(prev => [...prev, eventData]);
    setNextTimelinePoint(prev => Math.min(prev + 1, 7));
  };
  
  // Register refs when components mount
  const registerPlayerPanelRef = (methods: any) => {
    playerPanelRef.current = methods;
  };
  
  const registerGameClockRef = (methods: any) => {
    gameClockRef.current = methods;
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-blue-600 mb-8 text-center">Basketball Game Simulation</h1>
      
      <div className="flex flex-col md:flex-row gap-6 max-w-6xl mx-auto">
        {/* Left column: Player Panel and Event Generator */}
        <div className="w-full md:w-1/3">
          <PlayerPanel 
            currentQuarter={currentQuarter} 
            ref={registerPlayerPanelRef}
          />
          
          <EventBlockGenerator
            currentQuarter={currentQuarter}
            logAction={logPlayerAction}
            setPlayerStatus={setPlayerStatus}
            advanceGameTime={advanceGameTime}
            onEventGenerated={handleEventGenerated}
            timelinePoint={nextTimelinePoint}
          />
        </div>
        
        {/* Right column: Game Clock */}
        <div className="w-full md:w-2/3">
          <GameClock 
            onQuarterChange={handleQuarterChange}
            ref={registerGameClockRef}
          />
          
          {/* Timeline visualization */}
          {timelineEvents.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-4 mt-6">
              <h2 className="text-xl font-bold mb-4">Event Timeline</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">T#</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quarter</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IZOF</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Momentum</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Flow</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">sAA</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {timelineEvents.map((event) => (
                      <tr key={`T${event.timelinePoint}-Q${event.quarter}`}>
                        <td className="px-6 py-4 whitespace-nowrap">T{event.timelinePoint}</td>
                        <td className="px-6 py-4 whitespace-nowrap">Q{event.quarter}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{event.actions.length}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{event.surveyResponses?.emotionalArousal}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{event.surveyResponses?.momentum}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{event.surveyResponses?.flow}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${event.saaLevel === 'low' ? 'bg-green-100 text-green-800' : 
                            event.saaLevel === 'moderate' ? 'bg-orange-100 text-orange-800' : 
                            'bg-red-100 text-red-800'}`}>
                            {event.saaValue} U/mL
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;